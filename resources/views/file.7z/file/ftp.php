<?php

require BASE_URL.DS."resources".DS."views".DS."init.php";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $parameters = [
        'user' => $_POST['user_name'],
        'pass' => $_POST['pass'],
        'domain' => 'verarun.tech',
        'quota' => '500',
    ];
    $result = $cPanel->execute('uapi', "Ftp", "add_ftp", $parameters);
    if (!$result->status == 1) {
        setE("Cannot Create Ftp User Account  : {$result->messages[0]} | {$result->errors[0]}");
        header("location: /ftp");
        die();
    }else {
        setS("Ftp User account creation successful");
        header("location: /ftp");
        die();
    }
}
else {
    echo $twig->render("file/create.twig");
    $result = $cPanel->execute('uapi', 'Ftp', 'list_ftp');
    if (!$result->status == 1) {
        setE("Cannot fetch FTP Users list : {$result->messages[0]} | {$result->errors[0]}");
        header("location: /");
        die();
    }
    $ftp_user[0]="Not Available";
    $ite = 0;
    $result2 = $result->data;
     foreach ($result2 as $s) {
        $e = $s->user;
        $domain_ftp = substr(strrev($e), 0, strrpos(strrev($e), "@"));
        if (strrev(($domain_ftp)) === "verarun.tech") {
            $ftp_user[$ite] = $e;
            $ite = $ite + 1;
        }
    }
    echo $twig->render("file/list.twig", ['result' => $ftp_user]);
    clearMessages();
    die();
}