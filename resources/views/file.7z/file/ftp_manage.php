<?php

require BASE_URL.DS."resources".DS."views".DS."init.php";


if ($_SERVER['REQUEST_METHOD'] == "POST") {

    if (isset($_POST['adduser'])) {
        $parameters = [
            'user'    => $_POST['user_name'],
            'pass'    => $_POST['password'],
            'quota'   => '42',
            'domain'  => 'verarun.tech'
        ];
        $result = $cPanel->execute('uapi', "Ftp", "add_ftp", $parameters);
                if (!$result->status == 1) {
            setE("Cannot fetch Ftp Users list : {$result->messages[0]} | {$result->errors[0]}");
            header("location: /ftp");
            die();
        }else {
            setS("Ftp User account creation successful");
            header("location: /ftp");
            die();
        }
    }
    if (isset($_POST['removeuser'])) {
        $parameters = [
            'user'    => $_POST['user_name'],
            'destroy'   => '42',
            'domain'  => 'verarun.tech'
        ];
        $result = $cPanel->execute('uapi', "Ftp", "delete_ftp", $parameters);
        if (!$result->status == 1) {
            setE("Cannot fetch Ftp Users list : {$result->messages[0]} | {$result->errors[0]}");
            header("location: /ftp");
            die();
        }else {
            setS("Ftp User account Deletion successful");
            header("location: /ftp");
            die();
        }
    }

}
